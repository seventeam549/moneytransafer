Money Transfer Pro

Frontend:
- Upload frontend folder to Netlify

Backend:
- Upload backend folder to Render

Run backend locally:

npm install
npm start

Frontend API:
Change localhost URL in app.js after deploy.